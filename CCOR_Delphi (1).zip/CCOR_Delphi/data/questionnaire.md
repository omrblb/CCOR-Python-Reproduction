# CCOR Delphi - Questionnaire

This document contains the full text of the 15-item Delphi questionnaire used
as the basis for this project. Each KPI is evaluated using 3 statements,
rated on a 5-point Likert scale.

**Likert Scale**

| Value | Meaning (TR)              | Meaning (EN)        |
|-------|----------------------------|----------------------|
| 1     | Kesinlikle Katılmıyorum     | Strongly Disagree    |
| 2     | Katılmıyorum                | Disagree             |
| 3     | Kararsızım                  | Neutral              |
| 4     | Katılıyorum                 | Agree                |
| 5     | Kesinlikle Katılıyorum       | Strongly Agree       |

---

## KPI 1 - Lead to Contract

| Question ID | Statement (TR) | Statement (EN) |
|---|---|---|
| Soru1 | Lead-to-Contract Cycle Time müşteri zinciri performansını ölçmek için kritik bir göstergedir. | Lead-to-Contract Cycle Time is a critical indicator for measuring customer chain performance. |
| Soru2 | Lead-to-Contract süresinin azaltılması müşteri memnuniyetini artırır. | Reducing Lead-to-Contract time increases customer satisfaction. |
| Soru3 | Lead-to-Contract süresi satış başarısını doğrudan etkiler. | Lead-to-Contract time directly affects sales success. |

## KPI 2 - Customer Growth

| Question ID | Statement (TR) | Statement (EN) |
|---|---|---|
| Soru4 | Yeni müşteri sayısındaki artış işletme performansını gösterir. | The increase in the number of new customers reflects business performance. |
| Soru5 | Customer Growth müşteri zinciri başarısının temel göstergelerinden biridir. | Customer Growth is one of the core indicators of customer chain success. |
| Soru6 | Yeni müşteri kazanımı uzun dönemli büyüme için kritik öneme sahiptir. | Acquiring new customers is critical for long-term growth. |

## KPI 3 - Repurchasing Customers

| Question ID | Statement (TR) | Statement (EN) |
|---|---|---|
| Soru7 | Tekrar satın alan müşteri sayısı müşteri sadakatini gösterir. | The number of repurchasing customers reflects customer loyalty. |
| Soru8 | Repurchasing Customers KPI'ı müşteri ilişkilerinin başarısını ölçer. | The Repurchasing Customers KPI measures the success of customer relationships. |
| Soru9 | Mevcut müşteriyi elde tutmak yeni müşteri kazanmaktan daha değerlidir. | Retaining existing customers is more valuable than acquiring new ones. |

## KPI 4 - Revenue Growth

| Question ID | Statement (TR) | Statement (EN) |
|---|---|---|
| Soru10 | Revenue Growth işletmenin başarısını ölçmek için önemli bir göstergedir. | Revenue Growth is an important indicator for measuring business success. |
| Soru11 | Gelir artışı müşteri zinciri süreçlerinin etkinliğini yansıtır. | Revenue growth reflects the effectiveness of customer chain processes. |
| Soru12 | Revenue Growth KPI'ı stratejik karar verme süreçlerinde kullanılmalıdır. | The Revenue Growth KPI should be used in strategic decision-making processes. |

## KPI 5 - Cost of Selling Ratio

| Question ID | Statement (TR) | Statement (EN) |
|---|---|---|
| Soru13 | Satış maliyetlerinin kontrol edilmesi müşteri zinciri performansını etkiler. | Controlling selling costs affects customer chain performance. |
| Soru14 | Cost of Selling / Revenue oranı önemli bir performans göstergesidir. | The Cost of Selling / Revenue ratio is an important performance indicator. |
| Soru15 | Satış maliyetlerinin düşürülmesi kârlılığı artırır. | Reducing selling costs increases profitability. |

---

## Demographic Questions

| Question ID | Statement (TR) | Statement (EN) | Options |
|---|---|---|---|
| Soru16 | Mesleğiniz | Occupation | Öğrenci / Akademisyen / Yazılım Geliştirici / Veri Analisti / SAP Danışmanı / Diğer |
| Soru17 | İş deneyimi | Work experience | 0-1 yıl / 1-3 yıl / 3-5 yıl / 5+ yıl |

---

## Note

These statements were used as the conceptual basis for generating the
synthetic survey responses in `data/raw_survey_responses.csv`
(columns `Soru1`...`Soru15`, plus `Meslek` and `Tecrube` for the demographic
questions). No real respondents completed this questionnaire; response values
were generated programmatically (see `generate_survey_data.py`).
