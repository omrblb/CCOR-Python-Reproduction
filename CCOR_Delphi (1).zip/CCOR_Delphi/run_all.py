"""
run_all.py

Tum Delphi pipeline'ini sirayla calistirir:
1. generate_survey_data.py
2. process_round1.py
3. simulate_round2.py
4. consensus_analysis.py
5. make_charts.py
"""

import subprocess
import sys

scripts = [
    "generate_survey_data.py",
    "process_round1.py",
    "simulate_round2.py",
    "consensus_analysis.py",
    "make_charts.py",
]

for script in scripts:
    print(f"\n{'='*50}")
    print(f"Running {script}")
    print(f"{'='*50}")
    result = subprocess.run([sys.executable, script])
    if result.returncode != 0:
        print(f"Error running {script}, stopping.")
        sys.exit(1)

print("\nPipeline tamamlandi. Sonuclar 'outputs/' klasorunde.")
