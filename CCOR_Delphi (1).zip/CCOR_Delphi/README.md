# CCOR Delphi - KPI Consensus Analysis

[![Python](https://img.shields.io/badge/Python-3.10%2B-blue)](https://www.python.org/)
[![License](https://img.shields.io/badge/License-MIT-green)](LICENSE)

This project is a reproduction-style implementation of the Delphi method described
in the CCOR (Customer Chain Operations Reference) model literature. It evaluates
the importance/consensus level of 5 key performance indicators (KPIs) using a
two-round Delphi-style scoring process.

## KPIs Evaluated
- Lead-to-Contract Cycle Time
- Customer Growth
- Repurchasing Customers
- Revenue Growth
- Cost of Selling Ratio

## Methodology

The original CCOR article applies a Delphi survey to a panel of experts who score
each KPI on a 1-5 Likert scale across two rounds, with consensus defined as >=75%
of participants scoring an item >= 4.

In this project:

- **Survey instrument**: A 15-item questionnaire (3 items per KPI) based on the
  Delphi questionnaire structure proposed in the CCOR framework.
- **Round 1 data**: Simulated survey responses for 15 synthetic participants,
  generated with a normal distribution centered around values reported in the
  source literature (see `generate_survey_data.py`). **This is a synthetic /
  demo dataset, not data collected from real respondents.**
- **Round 2 data**: Simulated using a convergence rule that mimics the Delphi
  feedback effect — participants whose Round 1 score was notably below the
  group average move closer to the group mean, while extreme outliers are
  pulled slightly toward the center (see `simulate_round2.py`).
- **Consensus**: Calculated as the percentage of participants scoring >= 4 on
  each KPI, for both rounds.

## Project Structure

```
CCOR_Delphi/
├── data/
│   ├── questionnaire.md             # Full text of the 15-item Delphi questionnaire
│   ├── raw_survey_responses.csv   # 15-item question-level synthetic responses
│   ├── round1.csv                  # Round 1 KPI-level scores (per participant)
│   └── round2.csv                  # Round 2 (simulated) KPI-level scores
├── outputs/
│   ├── dashboard_data.csv          # Power BI-ready summary table
│   ├── average_score_comparison.png
│   ├── consensus_comparison.png
│   └── round2_consensus_ranking.png
├── generate_survey_data.py
├── process_round1.py
├── simulate_round2.py
├── consensus_analysis.py
├── make_charts.py
├── run_all.py
├── requirements.txt
└── .gitignore
```

## How to Run

```bash
git clone https://github.com/<your-username>/CCOR_Delphi.git
cd CCOR_Delphi

pip install -r requirements.txt

# Run the full pipeline at once
python run_all.py
```

Or run each step individually:

```bash
python generate_survey_data.py   # creates data/raw_survey_responses.csv
python process_round1.py         # creates data/round1.csv
python simulate_round2.py        # creates data/round2.csv
python consensus_analysis.py     # creates outputs/dashboard_data.csv
python make_charts.py            # creates charts in outputs/
```

## Results Summary

| KPI                     | R1 Avg | R1 Consensus % | R2 Avg | R2 Consensus % |
|-------------------------|--------|----------------|--------|----------------|
| Lead_to_Contract        | 4.07   | 73.33          | 4.13   | 80.00          |
| Customer_Growth         | 4.42   | 93.33          | 4.49   | 100.00         |
| Repurchasing_Customers  | 4.02   | 66.67          | 4.09   | 73.33          |
| Revenue_Growth          | 4.38   | 86.67          | 4.51   | 100.00         |
| Cost_Ratio              | 3.62   | 33.33          | 3.82   | 46.67          |

Round 2 shows the expected Delphi convergence behavior: consensus increases
across all KPIs. Four out of five KPIs reach or exceed the 75% consensus
threshold by Round 2, while **Cost of Selling Ratio** remains the most
contested KPI — consistent with it being the most subjective/variable metric
in the original CCOR framework.

## Power BI Integration

`outputs/dashboard_data.csv` is structured for direct import into Power BI:
- `Round` (Round1 / Round2)
- `KPI`
- `Average_Score`
- `Consensus_Percent`

This can be used to build:
- A Round1 vs Round2 comparison chart
- A consensus ranking visual with a 75% threshold line
- KPI-level average score trend

## Note on Data

All survey response data in this project is **synthetically generated** for
demonstration purposes, based on the question structure and consensus
thresholds described in the CCOR Delphi literature. No real participants were
surveyed.
