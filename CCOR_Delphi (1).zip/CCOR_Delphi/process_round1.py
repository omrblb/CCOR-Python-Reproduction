"""
process_round1.py

raw_survey_responses.csv dosyasini okur.
Her katilimci icin 15 soru cevabini 5 KPI skoruna indirir
(her KPI'in 3 sorusunun ortalamasi).

Cikti: data/round1.csv
Satirlar = katilimcilar, sutunlar = KPI'lar (Expert/Participant bazinda Round1 skorlari)
"""

import pandas as pd

df = pd.read_csv("data/raw_survey_responses.csv")

kpi_map = {
    "Lead_to_Contract": ["Soru1", "Soru2", "Soru3"],
    "Customer_Growth": ["Soru4", "Soru5", "Soru6"],
    "Repurchasing_Customers": ["Soru7", "Soru8", "Soru9"],
    "Revenue_Growth": ["Soru10", "Soru11", "Soru12"],
    "Cost_Ratio": ["Soru13", "Soru14", "Soru15"],
}

round1 = pd.DataFrame()
round1["Expert"] = df["Participant"]

for kpi, questions in kpi_map.items():
    # Katilimci bazinda KPI skoru = ilgili 3 sorunun ortalamasi
    round1[kpi] = df[questions].mean(axis=1).round(2)

round1.to_csv("data/round1.csv", index=False)

print("Round1 KPI skorlari olusturuldu -> data/round1.csv")
print(round1)
