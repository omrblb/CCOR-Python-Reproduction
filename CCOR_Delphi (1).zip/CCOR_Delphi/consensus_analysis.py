"""
consensus_analysis.py

Round1 ve Round2 verilerini kullanarak:
- Her KPI icin ortalama skor
- Consensus % (puani >= 4 olan katilimci orani)
hesaplar ve Power BI icin tek bir CSV uretir.

Cikti: outputs/dashboard_data.csv
"""

import pandas as pd

round1 = pd.read_csv("data/round1.csv")
round2 = pd.read_csv("data/round2.csv")

kpis = round1.columns[1:]


def compute_stats(df, round_name):
    results = []
    for kpi in kpis:
        mean_score = df[kpi].mean()
        agree_count = (df[kpi] >= 4).sum()
        consensus = round((agree_count / len(df)) * 100, 2)
        results.append({
            "Round": round_name,
            "KPI": kpi,
            "Average_Score": round(mean_score, 2),
            "Consensus_Percent": consensus
        })
    return results


results = compute_stats(round1, "Round1") + compute_stats(round2, "Round2")

dashboard_df = pd.DataFrame(results)

dashboard_df.to_csv("outputs/dashboard_data.csv", index=False)

print("Consensus analizi tamamlandi -> outputs/dashboard_data.csv")
print(dashboard_df)
