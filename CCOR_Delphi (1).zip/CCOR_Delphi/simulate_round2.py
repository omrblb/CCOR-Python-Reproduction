"""
simulate_round2.py

Delphi yonteminin 2. turunu simule eder.

Mantik:
- Her KPI icin grup ortalamasi hesaplanir.
- Katilimcilara bu ortalama "gosterilmis" gibi varsayilir.
- Ortalamanin altinda kalanlar puanlarini 1 artirir,
  ustunde olanlar 1 azaltir (1-5 sinirini asmadan).
- Bu, katilimcilarin grup goruslerine yakinsama egilimini modelleyen,
  literaturdeki Delphi yakinsama davranisina dayanan bir simulasyondur.

Girdi: data/round1.csv
Cikti: data/round2.csv
"""

import pandas as pd

df = pd.read_csv("data/round1.csv")

kpis = df.columns[1:]

df2 = df.copy()

THRESHOLD = 0.5  # ortalamadan bu kadar uzak olanlar yakinsasin

for kpi in kpis:
    avg = df[kpi].mean()

    for idx in df.index:
        current = df.loc[idx, kpi]

        if current < avg - THRESHOLD:
            # Ortalamanin belirgin altinda kalanlar gruba yaklasir (yukari)
            new_val = current + 1
        elif current > avg + 1.2:
            # Sadece asiri yuksek (cok aykiri) degerler hafifce gruba ceker
            new_val = current - 1
        else:
            new_val = current

        # 1-5 araliginda sinirla
        new_val = max(1, min(5, new_val))
        df2.loc[idx, kpi] = round(new_val, 2)

df2.to_csv("data/round2.csv", index=False)

print("Round2 (simule edilmis) skorlar olusturuldu -> data/round2.csv")
print(df2)
