"""
generate_survey_data.py

CCOR Delphi anketi icin sentetik (simulated) katilimci cevaplari uretir.
15 soru (5 KPI x 3 soru) + demografik bilgiler.

NOT: Bu veri gercek katilimcilardan toplanmamistir. CCOR modelinde
onerilen KPI cercevesine dayanan Delphi anketi sorulari kullanilarak,
literaturdeki dagilima yakin sentetik cevaplar uretilmistir.
"""

import pandas as pd
import numpy as np

np.random.seed(42)

N_PARTICIPANTS = 15

# 5 KPI, her biri 3 soru
kpi_map = {
    "Lead_to_Contract": ["Soru1", "Soru2", "Soru3"],
    "Customer_Growth": ["Soru4", "Soru5", "Soru6"],
    "Repurchasing_Customers": ["Soru7", "Soru8", "Soru9"],
    "Revenue_Growth": ["Soru10", "Soru11", "Soru12"],
    "Cost_Ratio": ["Soru13", "Soru14", "Soru15"],
}

all_questions = [q for qs in kpi_map.values() for q in qs]

# Her KPI icin "merkez" puan (literatur/CCOR makalesindeki egilime yakin
# olacak sekilde, genelde 4 civari, Cost_Ratio biraz daha dusuk/dagilimli)
kpi_center = {
    "Lead_to_Contract": 4.2,
    "Customer_Growth": 4.4,
    "Repurchasing_Customers": 4.0,
    "Revenue_Growth": 4.5,
    "Cost_Ratio": 3.7,
}

meslekler = [
    "Ogrenci", "Akademisyen", "Yazilim Gelistirici",
    "Veri Analisti", "SAP Danismani", "Diger"
]
tecrubeler = ["0-1 yil", "1-3 yil", "3-5 yil", "5+ yil"]

rows = []

for i in range(1, N_PARTICIPANTS + 1):
    row = {"Participant": f"P{i:02d}"}

    for kpi, questions in kpi_map.items():
        center = kpi_center[kpi]

        for q in questions:
            # Merkez deger etrafinda normal dagilim, 1-5 araliginda kirpilir
            val = np.random.normal(loc=center, scale=0.8)
            val = int(round(val))
            val = max(1, min(5, val))
            row[q] = val

    # Demografik bilgiler
    row["Meslek"] = np.random.choice(meslekler, p=[0.25, 0.2, 0.25, 0.15, 0.1, 0.05])
    row["Tecrube"] = np.random.choice(tecrubeler, p=[0.3, 0.3, 0.2, 0.2])

    rows.append(row)

df = pd.DataFrame(rows)

# Sutun siralamasi: Participant, Soru1..Soru15, Meslek, Tecrube
col_order = ["Participant"] + all_questions + ["Meslek", "Tecrube"]
df = df[col_order]

df.to_csv("data/raw_survey_responses.csv", index=False)

print("Sentetik anket verisi olusturuldu -> data/raw_survey_responses.csv")
print(df.head())
