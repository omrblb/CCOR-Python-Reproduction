"""
make_charts.py

outputs/dashboard_data.csv'yi okuyup gorsellestirir:
1. Round1 vs Round2 - KPI bazinda ortalama skor karsilastirmasi
2. Round1 vs Round2 - KPI bazinda consensus % karsilastirmasi
3. Round2 consensus % siralamasi (bar chart)

Ciktilar: outputs/ klasorune PNG olarak kaydedilir.
"""

import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

df = pd.read_csv("outputs/dashboard_data.csv")

kpis = df["KPI"].unique()

round1 = df[df["Round"] == "Round1"].set_index("KPI")
round2 = df[df["Round"] == "Round2"].set_index("KPI")

# --- 1. Ortalama skor karsilastirmasi ---
x = np.arange(len(kpis))
width = 0.35

fig, ax = plt.subplots(figsize=(10, 6))
ax.bar(x - width/2, round1.loc[kpis, "Average_Score"], width, label="Round 1")
ax.bar(x + width/2, round2.loc[kpis, "Average_Score"], width, label="Round 2")

ax.set_ylabel("Ortalama Skor")
ax.set_title("KPI Bazinda Ortalama Skor - Round1 vs Round2")
ax.set_xticks(x)
ax.set_xticklabels(kpis, rotation=30, ha="right")
ax.set_ylim(0, 5)
ax.legend()
plt.tight_layout()
plt.savefig("outputs/average_score_comparison.png", dpi=150)
plt.close()

# --- 2. Consensus % karsilastirmasi ---
fig, ax = plt.subplots(figsize=(10, 6))
ax.bar(x - width/2, round1.loc[kpis, "Consensus_Percent"], width, label="Round 1")
ax.bar(x + width/2, round2.loc[kpis, "Consensus_Percent"], width, label="Round 2")

ax.axhline(75, color="red", linestyle="--", label="Consensus Esigi (%75)")
ax.set_ylabel("Consensus (%)")
ax.set_title("KPI Bazinda Consensus - Round1 vs Round2")
ax.set_xticks(x)
ax.set_xticklabels(kpis, rotation=30, ha="right")
ax.set_ylim(0, 110)
ax.legend()
plt.tight_layout()
plt.savefig("outputs/consensus_comparison.png", dpi=150)
plt.close()

# --- 3. Round2 consensus siralamasi ---
sorted_r2 = round2.loc[kpis, "Consensus_Percent"].sort_values(ascending=False)

fig, ax = plt.subplots(figsize=(10, 6))
ax.bar(sorted_r2.index, sorted_r2.values, color="seagreen")
ax.axhline(75, color="red", linestyle="--", label="Consensus Esigi (%75)")
ax.set_ylabel("Consensus (%)")
ax.set_title("Round2 - KPI Consensus Siralamasi")
ax.set_xticks(range(len(sorted_r2.index)))
ax.set_xticklabels(sorted_r2.index, rotation=30, ha="right")
ax.set_ylim(0, 110)
ax.legend()
plt.tight_layout()
plt.savefig("outputs/round2_consensus_ranking.png", dpi=150)
plt.close()

print("Grafikler olusturuldu:")
print(" - outputs/average_score_comparison.png")
print(" - outputs/consensus_comparison.png")
print(" - outputs/round2_consensus_ranking.png")
